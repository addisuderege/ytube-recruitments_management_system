#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set($camelClassName = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
#set($lastIndex = $PACKAGE_NAME.lastIndexOf('.'))
#set($basePackage = $PACKAGE_NAME.substring(0, $lastIndex))

import ${basePackage}.dto.${NAME}Dto;
import ${basePackage}.entity.${NAME};
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ${NAME}Mapper {

    ${NAME}Dto toDto(${NAME} ${camelClassName});

    ${NAME} fromDto(${NAME}Dto ${camelClassName}Dto);

    List<${NAME}Dto> toDtoList(List<${NAME}> ${camelClassName}Collection);

    List<${NAME}> fromDtoList(List<${NAME}Dto> ${camelClassName}Collection);

}