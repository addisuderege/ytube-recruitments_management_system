#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set($camelClassName = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
#set($lastIndex = $PACKAGE_NAME.lastIndexOf('.'))
#set($basePackage = $PACKAGE_NAME.substring(0, $lastIndex))

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.FieldType;
import org.springframework.data.mongodb.core.mapping.MongoId;

@Document(collection = "${camelClassName}")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ${NAME} {
    
    @MongoId(FieldType.OBJECT_ID)
    private String id;
}
