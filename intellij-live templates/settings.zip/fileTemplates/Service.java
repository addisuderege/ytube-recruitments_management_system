#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set($className = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
#set($lastIndex = $PACKAGE_NAME.lastIndexOf('.'))
#set($basePackage = $PACKAGE_NAME.substring(0, $lastIndex))

import ${basePackage}.dto.${NAME}Dto;

#parse("File Header.java")
public interface ${NAME}Service extends GenericService<${NAME}Dto> {
    
    ${NAME}Dto findById(String id);
    
}