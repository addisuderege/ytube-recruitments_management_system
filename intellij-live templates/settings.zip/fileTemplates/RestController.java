#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set($camelClassName = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
#set($lastIndex = $PACKAGE_NAME.lastIndexOf('.'))
#set($basePackage = $PACKAGE_NAME.substring(0, $lastIndex))

import ${basePackage}.dto.${NAME}Dto;
import ${basePackage}.dto.ResponseDto;
import ${basePackage}.entity.${NAME};
import ${basePackage}.service.${NAME}Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.extern.slf4j.Slf4j;

import javax.validation.Valid;
import javax.xml.ws.Response;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/${camelClassName}s")
@Slf4j
public class ${NAME}Controller {

    @Autowired
    private ${NAME}Service ${camelClassName}Service;

    @PostMapping
    public ResponseEntity save${NAME}(@Valid @RequestBody ${NAME}Dto ${camelClassName}) {
        log.info("save${NAME}");
        ${NAME}Dto saved${NAME} = ${camelClassName}Service.save(${camelClassName});
        return ResponseEntity.status(HttpStatus.CREATED).body(saved${NAME});
    }

    @GetMapping
    public ResponseEntity getAll${NAME}s() {
        log.info("getAll${NAME}");
        List<${NAME}Dto> jobCategories = ${camelClassName}Service.findAll();
        return ResponseEntity.ok(jobCategories);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity getDataById(@PathVariable String id) {
        log.info("getDataById");
        ${NAME}Dto jobCategoryDto = ${camelClassName}Service.findById(id);
        return ResponseEntity.ok(jobCategoryDto);
    }

    @PutMapping
    public ResponseEntity update${NAME}(@RequestBody ${NAME}Dto ${camelClassName}) {
        log.info("update${NAME}");
        ${NAME}Dto updated${NAME} = ${camelClassName}Service.update(${camelClassName});
        return ResponseEntity.ok(updated${NAME});
    }

    @DeleteMapping("/{id}")
    public ResponseEntity delete${NAME}(@PathVariable String id) {
        log.info("delete${NAME}");
        boolean isDeleted = ${camelClassName}Service.delete(id);
        return ResponseEntity.ok("${NAME} with the id \""+id+"\" is deleted Successfully");
    }
}
