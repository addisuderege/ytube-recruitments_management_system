#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set($className = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
#set($lastIndex = $PACKAGE_NAME.lastIndexOf('.'))
#set($basePackage = $PACKAGE_NAME.substring(0, $lastIndex))

import ${basePackage}.entity.${NAME};
import org.springframework.data.mongodb.repository.MongoRepository;
 
public interface ${NAME}Repo extends MongoRepository<${NAME}, String> {
}