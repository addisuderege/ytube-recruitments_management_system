#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#set($camelClassName = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
#set($lastIndex = $PACKAGE_NAME.lastIndexOf('.'))
#set($secondLastIndex = $lastIndex - 8)
#set($basePackage = $PACKAGE_NAME.substring(0, $secondLastIndex))

import ${basePackage}.dto.${NAME}Dto;
import ${basePackage}.dao.${NAME}Repo;
import ${basePackage}.entity.${NAME};
import ${basePackage}.exceptions.DataNotFoundException;
import ${basePackage}.exceptions.RecordDeleteException;
import ${basePackage}.mappers.${NAME}Mapper;
import ${basePackage}.service.${NAME}Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ${NAME}ServiceImpl implements ${NAME}Service {

    @Autowired
    private ${NAME}Repo ${camelClassName}Repo;
    @Autowired
    private ${NAME}Mapper ${camelClassName}Mapper;

    @Override
    public List<${NAME}Dto> findAll() {
        List<${NAME}> categories = ${camelClassName}Repo.findAll();
        if(categories == null || categories.isEmpty()) {
            throw new DataNotFoundException("Records Not Found");
        }
        return ${camelClassName}Mapper.toDtoList(categories);
    }

    @Override
    public ${NAME}Dto findById(String id) {
        Optional<${NAME}> category = ${camelClassName}Repo.findById(id);
        category.orElseThrow(() -> new DataNotFoundException("Record Not Found with the id : " + id));
        return ${camelClassName}Mapper.toDto(category.get());
    }

    @Override
    public ${NAME}Dto save(${NAME}Dto ${camelClassName}) {
        ${NAME} category = ${camelClassName}Repo.save(${camelClassName}Mapper.fromDto(${camelClassName}));
        return ${camelClassName}Mapper.toDto(category);
    }

    @Override
    public ${NAME}Dto update(${NAME}Dto ${camelClassName}) {
        ${NAME} category = ${camelClassName}Repo.save(${camelClassName}Mapper.fromDto(${camelClassName}));
        return ${camelClassName}Mapper.toDto(category);
    }

    @Override
    public boolean delete(String id) {
        Optional<${NAME}> record = ${camelClassName}Repo.findById(id);
        record.orElseThrow(() -> new RecordDeleteException("Record not found with id : "+ id));
        try {
            ${camelClassName}Repo.deleteById(id);
            return true;
        } catch (Exception e) {
           throw new RecordDeleteException("Error occurred while deleting the record with id : " + "id");
        }
    }


}